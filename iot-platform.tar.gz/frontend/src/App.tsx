import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { ConfigProvider, App as AntApp } from 'antd';
import zhCN from 'antd/locale/zh_CN';
import { useEffect } from 'react';
import MainLayout from './layouts/MainLayout';
import Dashboard from './pages/Dashboard';
import ProductList from './pages/product/ProductList';
import ProductDetail from './pages/product/ProductDetail';
import PluginList from './pages/plugin/PluginList';
import PluginDetail from './pages/plugin/PluginDetail';
import PushRules from './pages/push/PushRules';
import PushChannels from './pages/push/PushChannels';
import MessageTemplates from './pages/push/MessageTemplates';
import PushLogs from './pages/push/PushLogs';
import { useProductStore } from './stores/productStore';
import { usePluginStore } from './stores/pluginStore';
import { usePushStore } from './stores/pushStore';

function AppInit() {
  const fetchProducts = useProductStore((s) => s.fetchProducts);
  const fetchPlugins = usePluginStore((s) => s.fetchPlugins);
  const fetchAll = usePushStore((s) => s.fetchAll);

  useEffect(() => {
    fetchProducts();
    fetchPlugins();
    fetchAll();
  }, [fetchProducts, fetchPlugins, fetchAll]);

  return null;
}

function App() {
  return (
    <ConfigProvider
      locale={zhCN}
      theme={{
        token: {
          colorPrimary: '#1677ff',
          borderRadius: 6,
        },
      }}
    >
      <AntApp>
        <BrowserRouter>
          <AppInit />
          <Routes>
            <Route path="/" element={<MainLayout />}>
              <Route index element={<Navigate to="/dashboard" replace />} />
              <Route path="dashboard" element={<Dashboard />} />
              <Route path="products" element={<ProductList />} />
              <Route path="products/:id" element={<ProductDetail />} />
              <Route path="plugins" element={<PluginList />} />
              <Route path="plugins/:id" element={<PluginDetail />} />
              <Route path="push/rules" element={<PushRules />} />
              <Route path="push/channels" element={<PushChannels />} />
              <Route path="push/templates" element={<MessageTemplates />} />
              <Route path="push/logs" element={<PushLogs />} />
            </Route>
          </Routes>
        </BrowserRouter>
      </AntApp>
    </ConfigProvider>
  );
}

export default App;

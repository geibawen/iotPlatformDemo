export type PluginPlatform = 'iOS' | 'Android' | 'both';
export type PluginStatus = 'active' | 'inactive';
export type VersionStatus = 'draft' | 'testing' | 'released';

export interface Plugin {
  id: string;
  name: string;
  description: string;
  platform: PluginPlatform;
  productIds: string[];
  status: PluginStatus;
  createdAt: string;
  updatedAt: string;
}

export interface PluginVersion {
  id: string;
  pluginId: string;
  version: string;
  releaseNotes: string;
  fileName: string;
  fileSize: number; // bytes
  status: VersionStatus;
  createdAt: string;
}

export const PLUGIN_PLATFORM_LABELS: Record<PluginPlatform, string> = {
  iOS: 'iOS',
  Android: 'Android',
  both: 'iOS & Android',
};

export const VERSION_STATUS_LABELS: Record<VersionStatus, string> = {
  draft: '草稿',
  testing: '测试中',
  released: '已发布',
};
